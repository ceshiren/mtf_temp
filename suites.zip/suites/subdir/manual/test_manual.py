import allure
import pytest
from allure_commons._allure import StepContext

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase
from mtf.core.utils import Utils


class TestCaseDemo(TestBase):
    context = Context()
    name = str(__name__).split('.')[-1] + '.yaml'
    log.debug(name)
    context.load(name)

    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        context.store.testcases.values(),
        ids=context.store.testcases.keys()
    )
    def test_param(self, testcase):
        self.context.run_steps_by_testcase(testcase)

    def test_demo(self):
        self.step("1111")
        allure.attach('111', '1111',
                      allure.attachment_type.TEXT)
        self.step("222")
        with StepContext(title='3333', params={}):
            log.debug('3333333')
            allure.attach('3', '3', allure.attachment_type.TEXT)
        with allure.step('444'):
            log.debug('4444')
            allure.attach('4', '4', allure.attachment_type.TEXT)

        step5 = allure.step('555')
        step5.__enter__()
        log.debug('55')
        allure.attach('5', '5', allure.attachment_type.TEXT)
        step5.__exit__(None, None, None)
        allure.description('desc')
        allure.link('http://www.baidu.com')
