import math

import jinja2
import re

import yaml

from mtf.core.utils import Utils


# 推荐使用jinja2
def test_jinja():
    data = {'a': "3", 'b': 4}
    assert Utils.jinja("{{a}} {{b}}", data) == "3 4"
    assert Utils.jinja("{{b.c}}", {'a': "3", 'b': {"c": 1}}) == "1"
    assert Utils.jinja("{{math.floor(6.4)}}", {"math": math}) == "6"
    assert Utils.jinja("{{math.floor(6.4)}}", globals()) == "6"
    assert Utils.jinja("{{true}}", globals()) == str(True)
    assert Utils.jinja("a b {{a}}", data) == "a b 3"


def test_mustache():
    assert Utils.mustache("{{a}} {{b}}", {'a': "3", 'b': 4}) == "3 4"
    assert Utils.mustache("{{b.c}}", {'a': "3", 'b': {"c": 1}}) == "1"
    assert Utils.template("{{math.floor(6.4)}}", globals()) == "6"


def test_jinja2():
    for f in jinja2.Template("${1+2} ${a+b}").generate(a=1, b=2):
        print(f)


def test_to_json():
    d = {'a': b'123'}
    d = [1, 2, 3]
    print(Utils.to_json_str(d))
    print(Utils.to_json_object(d))


def test_nc():
    print(Utils.nc('ceshiren.com', 80, 'GET / HTTP/2\nHost: ceshiren.com'))

def test_get_yaml_files():
    print(Utils.get_yaml_files("../../csrmock/tests"))


def test_load():
    print(Utils.load("test_branch"))
    print(Utils().load("test_branch"))


def test_load_yaml():
    r = Utils.load_yaml(Utils.load("test_branch.yaml"))
    assert r['test_if'] is not None
