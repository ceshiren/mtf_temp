from typing import List

from mtf.core.context_base import ContextBase
from mtf.core.step import Step


class TestCase(ContextBase):
    steps: List[Step] = {}
    name = None
    desc = ""

    def __init__(self, steps: List[Step], context):
        self.steps = steps
        self._context = context

    def steps_run(self):
        self.get_context().run_steps(self.steps)
