import functools
import threading
from threading import Lock


#
# def Singleton(cls):
#     '''
#     方便去使用单例的一个用法  在需要做单例的class上添加这个装饰器即可
#     :param cls:
#     :return:
#     '''
#     lock = Lock()
#     _instance = {}
#
#     def _singleton(*args, **kargs):
#         lock.acquire()
#         if cls not in _instance:
#             _instance[cls] = cls(*args, **kargs)
#         lock.release()
#         return _instance[cls]
#
#     return _singleton
#

def Singleton(cls):
    cls.__new_original__ = cls.__new__

    @functools.wraps(cls.__new__)
    def singleton_new(cls, *args, **kwargs):
        tid = threading.current_thread().name
        if cls.__dict__.get('__it__') is None:
            cls.__it__ = {}
        else:
            pass

        it = cls.__it__.get(tid)
        if it is None:
            cls.__it__[tid] = it = cls.__new_original__(cls, *args, **kwargs)
            it.__init_original__(*args, **kwargs)
        else:
            pass

        return it

    cls.__new__ = singleton_new
    cls.__init_original__ = cls.__init__
    cls.__init__ = object.__init__
    return cls
