import logging

format_str = '[%(asctime).19s] %(levelname).1s %(filename)s:%(lineno)d:%(funcName)s: %(message)s'
logging.basicConfig(
    level=logging.INFO,
    format=format_str
)
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)
# todo: 自动保存到日志文件

# ch = logging.StreamHandler()
# formatter = logging.Formatter(format_str)
# ch.setFormatter(formatter)
# log.addHandler(ch)
