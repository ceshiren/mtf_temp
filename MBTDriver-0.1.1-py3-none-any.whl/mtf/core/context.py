from typing import List

from mtf.core.driver.appium_step import AppiumStep
from mtf.core.driver.selenium_step import SeleniumStep
from mtf.core.singleton import Singleton
from mtf.core.step import Step
from mtf.core.testcase import TestCase
from mtf.core.testcasestore import TestCaseStore
from mtf.core.utils import Utils


class Context:
    def __init__(self):
        self.store: TestCaseStore = None
        self.testcase: TestCase = None
        self.step: Step = None
        self._return_value = None
        self.context_current = None

        # 全局数据维护
        self.global_dict = {}
        # 保存每次的参数
        self._param_data_cur = {}

    def load(self, file_name):
        if self.store is None:
            self.store = TestCaseStore()
            self.store.set_context(self)
        else:
            pass

        self.store.load(Utils.load(file_name))
        return self

    def set_context(self, name):
        self.context_current = name

    def run_steps_by_testcase(self, steps: List[Step]):
        self.testcase = TestCase(steps, self)
        self.testcase.steps_run()

    def run_steps(self, steps: List[Step]):
        for step in steps:
            self.run_step(step)

        return self.return_value()

    def run_step(self, step: Step):
        if 'selenium' in step.keys():
            self.set_context('selenium')
        elif 'appium' in step.keys():
            self.set_context("appium")
        else:
            pass

        if self.context_current == 'selenium':
            step_new = SeleniumStep(step._dict)
        elif self.context_current == 'appium':
            step_new = AppiumStep(step._dict)
        else:
            step_new = step

        step_new.set_context(self)
        self._return_value = step_new.run()
        return self.return_value()

    def return_value(self):
        return self._return_value

    def set_param(self, kwargs):
        self._param_data_cur = kwargs
