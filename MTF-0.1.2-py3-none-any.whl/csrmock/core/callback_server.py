import json
import re

from flask import Flask, request, jsonify, current_app

from csrmock.core.protocol.protocol_factory import ProtocolFactory
from csrmock.core.protocol.protocol_json import ProtocolJson
from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.step import Step
from mtf.core.utils import Singleton, Utils
from csrmock.core.mock_server import MockServer


class CallBackServer:
    app = Flask(__name__)

    def __init__(self):
        pass

    def set_mock_server(self, mock_server):
        self.mock_server: MockServer = mock_server
        # self.app.config['mock_server']=self.mock_server

    @staticmethod
    @app.route('/', methods=['get'])
    def info():
        return {
            'data': Utils.to_json_object(MockServer()),
            'instance': str(MockServer()),
            'msg': 'ok'
        }

    # @staticmethod
    # @app.route('/<path:path>', methods=['get', 'post'])
    # def callback(path):
    #     print(request.data)
    #     req = {
    #         'args': request.args,
    #         'data': request.get_data(as_text=True),
    #         'path': request.path,
    #         'json': request.json
    #     }
    #     # current_app.config['history'].append(req)
    #     # print(json.dumps(req))
    #
    #     for mock in CallBackServer().get_mock_list():
    #         # print(jsonpath.jsonpath(req, core['req']))
    #         if len(re.findall(mock['req'], json.dumps(req))) > 0:
    #             return mock["res"]
    #         else:
    #             pass
    #
    #     return jsonify(req)

    @staticmethod
    @app.route('/core', methods=['get', 'post'])
    def mock():
        log.info(request.headers)

        method = str(request.method).lower()
        if method == 'post':

            log.info(f'{request.json}')
            req = request.json['req']
            res = request.json['res']
            config = request.json.get('config', None)
            protocol = request.json.get('protocol', None)
            schema = request.json.get('protocol', None)

            # ProtocolFactory.get_mock_object(req, res , protocol=protocol, config=config )

            MockServer().add_mock(
                req_matcher=req,
                res=res,
                protocol=protocol,
                config=config,
                schema=schema
            )
        else:
            pass
        return {
            'data': Utils.to_json_object(MockServer().mock_rules),
            'size': len(MockServer().mock_rules),
            'msg': 'ok'
        }

    @staticmethod
    @app.route('/history', methods=['get'])
    def history():
        return {
            'data': Utils.to_json_object(MockServer().history),
            'size': len(MockServer().history),
            'msg': 'ok'
        }

    @staticmethod
    @app.route('/config', methods=['get', 'post'])
    def config():
        method = str(request.method).lower()
        if method == 'post':
            MockServer().config.update(request.json)

        return {
            'data': MockServer().config,
            'msg': 'ok'
        }

    @staticmethod
    @app.route('/reset', methods=['post'])
    def reset():
        MockServer().reset()
        return {
            'data': Utils.to_json_object(MockServer().history),
            'size': len(MockServer().history),
            'msg': 'ok'
        }

    @staticmethod
    @app.route('/hook', methods=['post'])
    def hook():
        # todo:
        config = request.json.get('config', None)
        req = request.json.get('req', None)
        context = Context()
        r = context.run_steps_by_dict(config['action'])
        return {
            'data': r
        }

    @classmethod
    def start_server(self, port=8008):
        log.info(f"callback server listen on {port}")
        self.app.run(debug=True, port=port, use_reloader=False)


if __name__ == '__main__':
    callback = CallBackServer()
    callback.start_server()
