"""TCP-specific events."""
import sys
import threading
from time import time

import mitmproxy
from mitmproxy import ctx
from mitmproxy.utils import strutils
from mitmproxy.tools.main import mitmdump

from csrmock.core.mock_server import MockServer
from mtf.core.logger import log as log2
from mtf.core.singleton import Singleton
from mtf.core.utils import Utils


@Singleton
class MitmTcp:
    def __init__(self):
        self.mock_server = MockServer()
        self.mock_server.set_protocol("mmi")

        # self.mock_server.add_mock("$..[?(@.f1==12849)]", [1, 2, 3, 'abcd'])
        self.req = None
        self.res = None

    def tcp_start(self, flow: mitmproxy.tcp.TCPFlow):
        """
            A TCP connection has started.
        """
        pass
        # ctx.log.info("start")
        # ctx.log.info(str(flow.messages))
        # self.conn_origin = flow.server_conn

    def tcp_message(self, flow: mitmproxy.tcp.TCPFlow):
        """
            A TCP connection has received a message. The most recent message
            will be flow.messages[-1]. The message is user-modifiable.
        """
        message = flow.messages[-1]
        if message.from_client:
            self.req = message.content

            ctx.log.info(f'''
                tcp_message:
                from_client={message.from_client}
                content origin={strutils.bytes_to_escaped_str(self.req)}
            ''')

            # todo: 可选转发
            # flow.reply.send("demo", force=True)
            # flow.reply.commit()
            # flow.server_conn=self.echo_client.conn
            #if self.mock_server.is_forward(self.req):
            #flow.server_conn.address = "mitmproxy.org"

        else:
            self.res = message.content
            res_new = self.mock_server.mock(self.req, self.res)
            ctx.log.info(str(res_new))
            message.content = res_new
            format_req = self.mock_server.decode_req(self.req)
            format_res = self.mock_server.decode_res(res_new)
            record = {'req': format_req, 'res': format_res}
            self.mock_server.history.append(record)
            ctx.log.info(f'''
                tcp_message:
                from_client={message.from_client}
                content origin={strutils.bytes_to_escaped_str(self.res)}
                content modified={strutils.bytes_to_escaped_str(message.content)}
            ''')

    def tcp_error(self, flow: mitmproxy.tcp.TCPFlow):
        """
            A TCP error has occurred.
        """
        ctx.log.info("error")

    def tcp_end(self, flow: mitmproxy.tcp.TCPFlow):
        """
            A TCP connection has ended.
        """
        ctx.log.info("end")

    @classmethod
    def main(cls, listen=9102, host='127.0.0.1', port=65432):
        log2.debug(f'startup timestamp {time()} {threading.current_thread().name} {threading.current_thread().ident}')
        sys.argv = [
            __file__,
            "-p", str(listen),
            "--rawtcp",
            # "--tcp-hosts", "*",
            "-k",
            "-m", f'reverse:http://{host}:{port}',
            "-s", __file__
        ]

        from csrmock.core.callback_server import CallBackServer

        callbackserver_tcp = CallBackServer()
        Utils.thread(
            target=callbackserver_tcp.start_server,
            args=(8004,),
            name="callback_tcp",
        )

        from csrmock.core.tcp_server_echo import EchoServer
        echo_server_tcp = EchoServer()
        echo_server_tcp.start_in_background()

        mitmdump()

        # thread_mock = threading.Thread(target=mitmdump, name="callback")
        # thread_mock.start()
        # start_server()


addons = [
    MitmTcp()
]

if __name__ == '__main__':
    MitmTcp.main()