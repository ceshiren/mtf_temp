from jsonpath import jsonpath

from mtf.core.logger import log
from mtf.core.utils import Utils


class ProtocolMessage:
    def __init__(self, req_matcher=None, res_mock=None, config=None, schema=None):
        """
        :param req_matcher: 判断是否需要mock，如果这个表达式执行结果为真，就进行mock
        :param res_mock: 当mock匹配的时候，返回一个预期的res_mock
        """
        # 根据schema做一次类型转换

        # 存放每次接受的res
        self.res_real = None
        self.req_matcher = req_matcher
        # python结构体，表示mock res
        self.res = res_mock
        # python结构体，表示请求对应的数据格式
        self.req = None
        self.schema = schema
        if config is not None:
            self.config = config
        else:
            self.config = {
                'limit': -1,
                'action': []
            }

    def encode_res(self, res_real):
        '''
        当mock生效的时候，把原始的python结构体表示的res_mock编码成具体的协议的消息，比如二进制
        :return:
        '''
        return res_real

    def before_encode_res(self, res):
        """
        进行通用的response处理，比子类优先执行
        :return:
        """
        if isinstance(self.res, str):
            # self.res="python: res[0]='0'; "
            if self.res.startswith("python:"):
                expr = self.res[7:].strip()
                log.debug(expr)
                l = locals()
                log.debug(res)
                exec(expr, l)
                log.debug(l['res'])
                return l['res']
            else:
                pass
        else:
            pass
        return None

    def decode_req(self, req):
        '''
        把真实请求比如二进制解析为一个python标准结构
        :param req:
        :return:
        '''
        return req

    def decode_res(self, res):
        '''
        把返回结果比如二进制解析为一个python标准结构
        :param req:
        :return:
        '''
        return res

    def filter(self, req_real):
        log.debug(self.req_matcher)
        if isinstance(self.req_matcher, dict):
            expr = []
            for key, value in self.req_matcher.items():
                expr.append(f'@.{key} == {repr(value)}')
            self.req_matcher = f"$..[?({' and '.join(expr)})]"
        else:
            pass

        if self.req_matcher.startswith('$.'):
            log.debug(Utils.to_json_object([req_real]))
            return jsonpath(Utils.to_json_object([req_real]), self.req_matcher)

        # 支持python表达式
        # "python: '12' in req"
        elif self.req_matcher.startswith('python:'):
            expr = self.req_matcher[7:].strip()
            req = req_real
            result = eval(expr)
            log.debug(req)
            log.debug(result)
            return result
        else:
            log.error(f"don't know match method {self.req_matcher}")

    def is_me(self, req_real: bytes):
        '''
        识别是否是自己的协议
        :param req_real:
        :return:
        '''
        return True

    def hit(self, req_real, res_real=None, matcher=None):
        '''
        判断是否命中，把任意结构转成json，使用jsonpath去匹配
        尽量别重载这个方法

        :param res_real:
        :param req_real:
        :return:
        '''
        # 把真实数据解码为标准结构
        req_real = self.decode_req(req_real)
        log.debug(req_real)
        if res_real is not None:
            res_real = self.decode_res(res_real)
            log.debug(res_real)
        else:
            pass

        res = None
        if self.filter(req_real):
            if 'limit' in self.config:
                self.config['limit'] -= 1
            # 返回动态的mock结果
            res = self.before_encode_res(res_real)
            if res:
                pass
            else:
                # 返回写死的mock结果
                res = self.encode_res(self.res)
        else:
            pass
        return res
