import binascii

from core.mock_server import MockServer


class TestProtocolTcp:
    def setup_class(self):
        self.mock_server = MockServer()

    def test_tcp(self):
        self.mock_server.set_protocol('bin')
        req_bin = b'\x31\x32\x33\x34\x35\x36\x37\x38'
        res_bin = bytes((reversed(req_bin)))
        print(req_bin)
        print(res_bin)

        self.mock_server.add_mock(req_matcher={'f1': '1'}, res=['87654321'])
        req_real = req_bin
        res_mock = self.mock_server.mock(req=req_real, res=None)
        assert res_mock == res_bin


def test_schema():
    req = {'f1': '31'}
    schema = {'f1': 'hex'}
    req_expect = {'f1': '1'}

    def hex(raw: str):
        return binascii.unhexlify(raw.replace(' ', '')).decode()

    fun_dict = {
        'hex': hex
    }

    for k, v in schema.items():
        if k in req:
            req[k] = fun_dict[v](req[k])

    print(req)
    print(req_expect)
    assert req == req_expect
