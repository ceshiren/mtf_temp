from csrmock.core.protocol.protocol_message import ProtocolMessage
from csrmock.core.mock_server import MockServer
from csrmock.core.protocol.protocol_factory import ProtocolFactory


def test_get_mock_object():
    f = ProtocolFactory()
    r = f.get_mock_object(protocol=ProtocolMessage, req_matcher='aa', res_mock=None)
    assert r.req_matcher == 'aa'


def test_get_mock_object_package_class():
    f = ProtocolFactory()
    r = f.get_mock_object(
        protocol='csrmock.core.protocol.protocol_json.ProtocolJson',
        req_matcher='aa',
        res_mock=None)
    assert r.req_matcher == 'aa'
