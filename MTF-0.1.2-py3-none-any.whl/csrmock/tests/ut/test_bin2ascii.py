import binascii
import re
from struct import *

import yaml


def test_bin2ascii():
    bin = pack('<i', 10)
    print(bin)
    hex = binascii.hexlify(bin)
    print(hex)
    print(hex.decode('ascii'))
    hex2 = bin.hex()
    print(hex2)
    print(binascii.unhexlify(hex2))
    print(binascii.unhexlify(hex))


def test_mmi():
    s = 'eedc'
    bin = binascii.unhexlify(s)

    print(bin)
    print(unpack('<H', bin))


def test_int():
    s = '88 13 00 00'
    bin = binascii.unhexlify(s.replace(' ', ''))
    print(bin)
    print(unpack('<i', bin))


def test_yaml_hex():
    x = {'hex': '\x31\x32\x01\x00'}
    s = yaml.dump(x)
    print(s)
    y = yaml.load(s)
    print(y)
    assert y['hex'] == '\x31\x32\x01\x00'

    yaml_content = '''hex: "12\\x01\\x00"'''
    print(yaml_content)
    assert yaml.load(yaml_content)['hex'] == '\x31\x32\x01\x00'

    yaml_content = '''hex: 0xdcee'''
    assert yaml.load(yaml_content)['hex'] == 56558

    h = 'eedc'
    print(binascii.unhexlify(h))
    print(unpack('<H', binascii.unhexlify(h)))
    print(unpack('H', binascii.unhexlify(h)))
    print(unpack('>H', binascii.unhexlify(h)))

    h = 'dcee'
    print(binascii.unhexlify(h))
    print(unpack('<H', binascii.unhexlify(h)))
    print(unpack('H', binascii.unhexlify(h)))
    print(unpack('>H', binascii.unhexlify(h)))


def test_python():
    print(re.sub("(.{2})(.{3})", '\\1abcdeffgg', '123456'))


def test_python2():
    data = '123\n456'
    expr = 'line[3:5]=xx for line in data.split("\n")'
