from csrhook.core.trace import JVMTrace


def test_trace():
    jvm = JVMTrace()
    hooks = [
        # {
        #     'class': 'java.lang.String',
        #     'method': 'toString',
        #     'params': None
        # },
        {
            'class': 'com.ceshiren.springbootdemo.Greeting',
            'method': 'getContent',
            'params': None
        }
    ]
    jvm.trace(32281, hooks)
