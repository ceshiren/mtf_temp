from mtf.core.utils import Utils

# def test_server():
# 'http://127.0.0.1:9999/greeting?name=a'
#     jar='java -jar -Dserver.port=9999 ../bin/rest-demo-0.0.1-SNAPSHOT.jar'
#     p=Utils.subprocess(jar)
#     print(p)
