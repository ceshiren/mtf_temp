import frida
import sys

from mtf.core.logger import log
from mtf.core.utils import Utils


class JVMTrace:
    def trace(self, pid, hooks):
        session = frida.attach(pid)
        template = """
        console.log(Frida.version);
        Java.perform( function(){
        {% for item in hooks -%}
            var str = Java.use('{{ item['class'] }}');
            str.{{ item['method'] }}.overload({% if item['params'] %}{{ item['params'] }}{% endif %}).implementation = function(){
                return 'ceshiren.com'
            };
        {% endfor %}
        })
        """
        content = Utils.jinja(template, {'hooks': hooks})
        log.debug(f'content={content}')
        script = session.create_script(content)

        def on_message(message, data):
            log.debug(message)
            log.debug(data)

        script.on('message', on_message)
        script.load()

        sys.stdin.read()
