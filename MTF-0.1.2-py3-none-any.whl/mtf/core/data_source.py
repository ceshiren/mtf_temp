from __future__ import annotations

import abc
import os

import json
import xml.etree.ElementTree as ET
from typing import TYPE_CHECKING

import pandas as pd
import sqlalchemy
import xmltodict
import yaml
from sqlalchemy import Column
from sqlalchemy.engine import reflection
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

if TYPE_CHECKING:
    from mtf.core.utils import Utils


class DataSource:

    @classmethod
    def load(cls, file_path, *args, **kwargs):
        parser_factory = None
        file_type = file_path.split('.')[-1]
        if file_type == 'db' or '://' in file_path:
            # 判断字符串为数据库连接
            parser_factory = SqlRuleDataParserFactory()
            return parser_factory.create_parser(file_path, *args, **kwargs)
        if not os.path.isfile(file_path):
            from mtf.core.utils import Utils
            file_path = Utils.load(file_path)

        if file_type == "xlsx" or file_type == "xls":
            parser_factory = ExcelRuleDataParserFactory()
        elif file_type == "csv":
            parser_factory = CsvRuleDataParserFactory()
        elif file_type == "yaml" or file_type == "yml":
            parser_factory = YamlRuleDataParserFactory()
        elif file_type == "json":
            parser_factory = JsonRuleDataParserFactory()
        elif file_type == 'xml':
            parser_factory = XmlRuleDataParserFactory()
        elif file_type == 'pdf':
            # todo:
            pass
        elif file_type == 'doc' or file_type == 'docx':
            # todo: guoquan
            pass
        elif file_type in ['zip', 'jar', 'war']:
            # todo: xmind也是zip包
            pass
        else:
            # dsl
            parser_factory = TxtRuleDataParserFactory()
        return parser_factory.create_parser(file_path, *args, **kwargs)

    # 准备删除（已迁移到工厂方法 XmlRuleDataParserFactory 中）---------------------------------------------------
    def load_xml(self, path):
        from mtf.core.utils import Utils
        self.path = Utils.load(path)
        self.xml_data = ET.parse(self.path)
        with open(self.path) as fd:
            dict_data = xmltodict.parse(fd.read())
        return dict_data

    def dict_to_xml(self, path, data):
        if path is None:
            path = self.path
        file = open(path, 'w')
        file.write(xmltodict.unparse(data, pretty=True))

    def save_xml(self, path=None):
        if path is None:
            path = self.path
        self.xml_data.write(path, encoding="utf-8", xml_declaration=True)

    def find_all_by_xpath(self, xpath):
        return self.xml_data.findall(xpath)

    def find_text_by_xpath(self, xpath):
        return self.xml_data.find(xpath).text

    def set_text(self, xpath, data_value):
        self.xml_data.find(xpath).text = data_value

    def update_xml(self, xpath, value):
        self.set_text(xpath, value)
        self.xml_data.write(self.path, encoding="utf-8", xml_declaration=True)


# ---------------------------------------------------

class IRuleDataParserFactory(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def create_parser(self, *args, **kwargs):
        pass


class SqlRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path, *args, **kwargs):
        return self._open_sql(path, *args, **kwargs)

    @staticmethod
    def _open_sql(sql_url, table_name, *args, **kwargs):
        """
        通过数据库连接和数据库表名，获取表内全部数据
        :param sql_url: 数据库连接URL，示例： 数据库类型+数据库驱动名称://用户名:口令@机器地址:端口号/数据库名
        :param table_name: 数据库表名
        :param args:
        :param kwargs:
        :return:
        """

        def _get_model_class(engine, table_name):
            """
            动态生成表对应的model类
            :param engine:
            :return:
            """
            Base = declarative_base()
            insp = reflection.Inspector.from_engine(engine)
            p_keys = insp.get_pk_constraint(table_name)
            cols = {'__tablename__': table_name, }
            for i in insp.get_columns(table_name):
                if i['name'] in p_keys['constrained_columns']:
                    cols.update({i['name']: Column(i['type'], primary_key=True)})
                else:
                    cols.update({i['name']: Column(i['type'])})

            def to_dict(self):
                """
                将数据转换为字典
                :param self:
                :return:
                """
                return {c.name: getattr(self, c.name, None) for c in self.__table__.columns}

            cols.update({'to_dict': to_dict})
            return type(table_name, (Base,), cols)

        engine = sqlalchemy.create_engine(sql_url, *args, **kwargs)
        db_session = sessionmaker(bind=engine)
        result = db_session().query(_get_model_class(engine, table_name)).all()
        return result


class TxtRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path):
        with open(path, errors="ignore") as f:
            return f.read()


class ExcelRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path, sheet_name="", columns=None, orient="dict"):
        """
        打开 excel
        :param path: excel 路径
        :param sheet_name:
        :param columns: 取出指定列
        :param orient: 指定 to_dict 的类型，默认为 dicg
        :return:
        """
        df = pd.read_excel(path, sheet_name=sheet_name)
        if columns is not None:
            df = df[columns]
        return df.to_dict(orient=orient)


class CsvRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path, columns_start=0, columns_end=None, *args, **kwargs):
        """
        打开 csv
        :param path:
        :param columns_start: 列开始位置
        :param columns_end: 列结束位置
        :return:
        """
        train_data = pd.read_csv(path, *args, **kwargs)
        if columns_end is not None:
            slice_list = train_data.columns[columns_start: columns_end]
        else:
            slice_list = train_data.columns[columns_start:]
        train_data = train_data[slice_list]
        return train_data.to_dict(orient="records")


class YamlRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path):
        with open(path, encoding='UTF-8') as f:
            return yaml.safe_load(f)


class JsonRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path):
        with open(path, encoding='UTF-8') as f:
            return json.load(f)


class XmlRuleDataParserFactory(IRuleDataParserFactory):
    def create_parser(self, path):
        return XmlParse(path)


class XmlParse:
    def __init__(self, path):
        self.path = path
        self.xml_data = ET.parse(path)
        with open(path) as fd:
            self.dict_data = xmltodict.parse(fd.read())

    def dict_to_xml(self, data, path=None):
        if path is None:
            path = self.path
        file = open(path, 'w')
        file.write(xmltodict.unparse(data, pretty=True))

    def save_xml(self, path=None):
        if path is None:
            path = self.path
        self.xml_data.write(path, encoding="utf-8", xml_declaration=True)

    def find_all_by_xpath(self, xpath):
        return self.xml_data.findall(xpath)

    def find_text_by_xpath(self, xpath):
        return self.xml_data.find(xpath).text

    def set_text(self, xpath, data_value):
        self.xml_data.find(xpath).text = data_value

    def update_xml(self, xpath, value):
        self.set_text(xpath, value)
        self.xml_data.write(self.path, encoding="utf-8", xml_declaration=True)
