import allure
from allure_commons.types import LabelType


@allure.tag("x", "y")
def test_allure():
    allure.tag("x", "y")
    allure.title("title")
    allure.suite('suitename')
    allure.step("step")
    allure.label(LabelType.TAG, "mm")

    assert 1==1