# Author:Pegasus-Yang
# Time:2020/10/22 20:12
import pytest

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase


class TestCaseDemo(TestBase):
    context = Context()
    context.load(str(__name__).split('.')[-1] + '.yaml')

    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        context.store.testcases.values(),
        ids=context.store.testcases.keys()
    )
    def test_param(self, testcase):
        self.context.run_steps_by_testcase(testcase)
