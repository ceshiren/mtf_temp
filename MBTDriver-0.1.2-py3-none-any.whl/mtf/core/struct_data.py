class StructData:
    def from_file(path):
        pass

    def read(self, regex, line):
        pass
