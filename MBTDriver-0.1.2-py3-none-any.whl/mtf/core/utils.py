import binascii
import json
import os
import re
import socket
from struct import unpack, pack
from threading import Lock

import chevron
import yaml
from jinja2 import Template

from mtf.core.data_source import DataSource
from mtf.core.logger import log
import pkgutil

from mtf.core.singleton import Singleton


@Singleton
class Utils:
    path_list = []

    @classmethod
    def get_project_dir(cls):
        '''
        获得当前包的主目录
        :return:
        '''
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

    @classmethod
    def get_current_dir(cls, path):
        '''
        get_current_dir(__file__)
        获得当前文件所在的目录
        :param path:
        :return:
        '''
        return os.path.abspath(os.path.dirname(path))

    @classmethod
    def get_package_data(cls, package, file_name):
        '''
        获得包内的同级数据文件
        get_package_data(__package__, '1.data')
        :param package:
        :param file_name:
        :return:
        '''
        return pkgutil.get_data(package, file_name)

    @classmethod
    def load(cls, file_name):
        if len(Utils.path_list) == 0:
            current_dir = os.getcwd()
            for dir_path, dirs, files in os.walk(current_dir):
                for f in files:
                    # log.debug(f)
                    Utils().path_list.append(os.sep.join([dir_path, f]))
        else:
            pass

        for path in Utils().path_list:
            groups = re.findall(file_name, path)
            if len(groups) > 0:
                return path
        return None

    @classmethod
    def load_data(cls, file_name, *args, **kwargs):
        return DataSource.load(Utils.load(file_name), *args, **kwargs)

    @classmethod
    def load_yaml(cls, path):
        with open(path, encoding='UTF-8') as f:
            return yaml.safe_load(f)

    @classmethod
    def get_yaml_files(cls, path):
        paths = []

        if isinstance(path, list):
            paths = path
        else:
            paths.append(path)

        yaml_files = []
        for path in paths:
            if os.path.isfile(path):
                yaml_files.append(path)
            else:
                for dir_path, dirs, files in os.walk(path):
                    for f in files:
                        if f.endswith('.yaml'):
                            yaml_files.append(f'{dir_path}/{f}')

        return yaml_files

    @classmethod
    def template(cls, format_str: str, dict):
        # 兼容jinja原有语法，并支持新语法
        if format_str.strip().startswith("{{"):
            variable_start_string = '{{'
            variable_end_string = '}}'
        else:
            variable_start_string = '${'
            variable_end_string = '}'
        template = Template(
            format_str,
            variable_start_string=variable_start_string,
            variable_end_string=variable_end_string)
        return template.render(dict)

    @classmethod
    def eval(cls, format_str: str, dict):
        log.debug(format_str)
        return eval(format_str[2:-1], dict)

    @classmethod
    def jinja(cls, format_str, dict):
        template = Template(format_str)
        return template.render(dict)

    @classmethod
    def mustache(cls, format_str, dict):
        return chevron.render(format_str, dict)

    @classmethod
    def _json_decode(cls, o):
        if hasattr(o, '__dict__'):
            if o.__dict__ == {}:
                return str(o.__class__)
            else:
                return o.__dict__
        elif isinstance(o, bytes):
            return o.decode("utf-8")
        else:
            return str(o)

    @classmethod
    def to_json_str(cls, o, indent=2):
        return json.dumps(o, default=cls._json_decode, indent=indent, ensure_ascii=False)

    @classmethod
    def to_json_object(cls, o):
        if isinstance(o, str):
            return json.loads(o)
        else:
            return cls.to_json_object(cls.to_json_str(o))

    @classmethod
    def to_int(cls, b: bytes):
        return unpack('<h', b)[0]

    @classmethod
    def to_s(cls, b: bytes):
        return unpack(f'<{len(b)}s', b)[0]

    @classmethod
    def to_b(cls, o):
        binascii.hexlify()
        if isinstance(o, str):
            return pack(f'<{len(o.encode("utf-8"))}s', o)
        elif isinstance(o, int):
            return pack('<h', bytes([o]))
        else:
            log.error(f"dont know {o}")

    @classmethod
    def nc(self, ip, port, data):
        if isinstance(data, bytes):
            data_bin = data
        else:
            data_bin = str(data).encode()

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((ip, port))
            s.sendall(data_bin)
            data = s.recv(1024)
            return data

    @classmethod
    def recursion(cls, d):
        if isinstance(d, list):
            data = []
            for l in d:
                yield from cls.recursion(l)
                data.append(l)
            return data
        elif isinstance(d, dict):
            data = {}
            for k, v in d.items():
                kk = yield from cls.recursion(k)
                vv = yield from cls.recursion(v)
                data[kk] = vv
                yield {k: v}

            return data
        else:
            yield d
            return d
