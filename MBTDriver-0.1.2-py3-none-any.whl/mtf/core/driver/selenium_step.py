from selenium import webdriver
from selenium.webdriver import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
import mtf.core.step


class SeleniumStep(mtf.core.step.Step):
    # todo: 实现逻辑
    # todo：异常处理逻辑
    # todo: base page实现

    _driver: WebDriver = None

    def __init__(self, dict={}):
        super().__init__(dict)

    def get_driver(self):
        return self.get_context().global_dict['_selenium_driver']

    def set_driver(self, driver):
        self.get_context().global_dict['_selenium_driver'] = driver

    def set_element(self, element):
        self.get_context().global_dict['_selenium_element'] = element

    def get_element(self):
        return self.get_context().global_dict['_selenium_element']

    def selenium(self, server, caps):
        driver = webdriver.Remote(server, caps)
        self.set_driver(driver)
        self.get_driver().implicitly_wait(10)

    def chrome(self):
        DesiredCapabilities.CHROME

    def get(self, url):
        self.get_driver().get(url)

    def id(self, value):
        element = self.get_driver().find_element(By.ID, value)
        self.set_element(element)

    def xpath(self, value):
        element = self.get_driver().find_element(By.XPATH, value)
        self.set_element(element)

    def text(self, value):
        element = self.get_driver().find_element(By.XPATH, f'//*[@innerText="{value}"]')
        self.set_element(element)

    def click(self):
        self.get_element().click()

    def send_keys(self, text):
        self.get_element().send_keys(text)

    def get_attribute(self, name):
        return self.get_element().get_attribute(name)
