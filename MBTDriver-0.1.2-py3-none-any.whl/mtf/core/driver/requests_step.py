from mtf.core.step import Step


class RequestsStep(Step):
    def get(self):
        pass

    def post(self):
        pass
