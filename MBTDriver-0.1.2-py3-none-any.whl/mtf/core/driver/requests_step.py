import json
import re
from json.decoder import JSONDecodeError

import pymysql
import requests
from jsonpath import jsonpath
from pymysql.cursors import DictCursor
from requests import Session

from mtf.core.step import Step


class SQL:
    """
    SQL数据库连接基类，封装公共的SQL数据库方法
    """

    def __init__(self, *args, **kwargs):
        self.connect = self._get_conn(*args, **kwargs)
        self.cursor = None

    def _get_conn(self, *args, **kwargs):
        pass

    def _get_cursor(self):
        if self.cursor is None:
            self.cursor = self.connect.cursor()
        return self.cursor

    def execute(self, sql, params=None):
        self._get_cursor().execute(sql, params)

    def commit(self):
        self.connect.commit()

    def result(self, num='all'):
        if int(num) == 1:
            return self._get_cursor().fetchone()
        elif num == 'all':
            return self._get_cursor().fetchall()
        else:
            return self._get_cursor().fetchmany(int(num))

    def rollback(self):
        self.connect.rollback()

    def close_conn(self):
        self.connect.close()

    def close_cursor(self):
        if self.cursor:
            self.cursor.close()
            self.cursor = None

class MySQL(SQL):
    def _get_conn(self, *args, **kwargs) -> pymysql.Connection:
        return pymysql.connect(*args, **kwargs)


class RequestsStep(Step):

    def __init__(self, dict={}):
        super().__init__(dict)

    def _set_session(self, session):
        self.get_context().global_dict['_requests_session'] = session

    def _get_session(self) -> Session:
        return self.get_context().global_dict.get('_requests_session', None)

    def _set_base_url(self, base_url):
        self.get_context().global_dict['_requests_base_url'] = base_url

    def _get_base_url(self) -> str:
        return self.get_context().global_dict.get('_requests_base_url', None)

    def _set_response(self, response):
        self.get_context().global_dict['_requests_response'] = response

    def _get_response(self) -> list:
        return self.get_context().global_dict.get('_requests_response', None)

    def _set_sql_conn(self, sql_conn):
        self.get_context().global_dict['_requests_sql_conn'] = sql_conn

    def _get_sql_conn(self) -> list:
        return self.get_context().global_dict.get('_requests_sql_conn', None)

    def _set_sql_result(self, sql_result):
        self.get_context().global_dict['_requests_sql_result'] = sql_result

    def _get_sql_result(self):
        return self.get_context().global_dict.get('_requests_sql_result', None)

    def requests(self, base_url=None, new=False):
        session = self._get_session()
        if session is None or new is True:
            session = requests.Session()
            self._set_session(session)
        if base_url is not None:
            self._set_base_url(base_url)

    def mysql(self, **kwargs):
        mysql = MySQL(cursorclass=DictCursor, **kwargs)
        self._set_sql_conn(['mysql', mysql])

    def _sql(self, sql: str, params=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            if sql_conn[0] == 'mysql':
                sql_object = sql_conn[1]
                sql_object.execute(sql, params)
            return sql_conn[1]
        else:
            raise Exception('No sql Connection')

    def sql_select(self, sql, params=None):
        sql_conn = self._sql(sql, params)
        result = sql_conn.result()
        sql_conn.close_cursor()
        self._set_sql_result(result)
        return result

    def sql_update(self, sql, params=None):
        sql_conn = self._sql(sql, params)
        try:
            sql_conn.commit()
            sql_conn.close_cursor()
        finally:
            sql_conn.rollback()
            sql_conn.close_cursor()

    def sql_delete(self, sql, params=None):
        sql_conn = self._sql(sql, params)
        try:
            sql_conn.commit()
            sql_conn.close_cursor()
        finally:
            sql_conn.rollback()
            sql_conn.close_cursor()

    def sql_insert(self, sql, params=None):
        sql_conn = self._sql(sql, params)
        try:
            sql_conn.commit()
            sql_conn.close_cursor()
        finally:
            sql_conn.rollback()
            sql_conn.close_cursor()

    def request(self, method, url='', **kwargs):
        if not url.startswith('http') and self._get_base_url():
            url = self._get_base_url() + url
        res = self._get_session().request(method=method, url=url, **kwargs)
        try:
            res = res.json()
            self._set_response(['json', res])
        except JSONDecodeError:
            res = res.text
            self._set_response(['text', res])
        return res

    def get(self, url='', **kwargs):
        return self.request('get', url=url, **kwargs)

    def post(self, url='', **kwargs):
        return self.request('post', url=url, **kwargs)

    def delete(self, url='', **kwargs):
        return self.request('delete', url=url, **kwargs)

    def put(self, url='', **kwargs):
        return self.request('put', url=url, **kwargs)

    def head(self, url='', **kwargs):
        return self.request('head', url=url, **kwargs)

    def patch(self, url='', **kwargs):
        return self.request('patch', url=url, **kwargs)

    def options(self, url='', **kwargs):
        return self.request('options', url=url, **kwargs)

    def get_res_data(self, path: str):
        """
        根据表达式获取上次接口返回中的数据，支持jsonpath和正则表达式
        :param path: jsonpath表达式或者正则表达式
        :return: 获取到的数据，无结果则返回False
        """
        res = self._get_response()
        if res:
            if res[0] == 'json' and path.startswith('$'):
                return jsonpath(res[1], path)
            else:
                result = re.findall(path, str(res[1]))
                if result:
                    return False
                elif len(result) == 1:
                    return result[0]
                else:
                    return result
        return False
