import os
from copy import copy
from typing import List, Dict

import yaml

from mtf.core.context_base import ContextBase
from mtf.core.logger import log
from mtf.core.page_object import PageObject
from mtf.core.step import Step
from mtf.core.utils import Utils, Singleton


class TestCaseStore(ContextBase):

    def __init__(self):
        self.methods: Dict[str, List[Step]] = {}
        self.testcases_param: Dict[str, List[Step]] = {}
        self.testcases: Dict[str, List[Step]] = {}
        self.setup_class: List[Step] = []
        self.teardown_class: List[Step] = []
        self.setup: List[Step] = []
        self.teardown: List[Step] = []
        self.class_pool = {}

        # 参数化的原始数据
        self.params_dict = {}
        # 生成的数据列表
        self.params_data = []

    def load(self, path) -> 'TestCaseStore':
        # todo: 支持多次load
        # self.__init__()
        for path in Utils.get_yaml_files(path):
            log.debug(f'path={path}')
            methods = Utils.load_yaml(path)

            class_methods = {}
            for method_name, steps in methods.items():
                method_temp = []
                for dict in steps:
                    method_temp.append(Step(dict))

                if method_name.startswith('test_'):
                    log.debug(f'testcase add {method_name}')
                    self.testcases_param[method_name] = method_temp
                    # todo: 支持内嵌setup

                elif method_name == 'setup_class':
                    log.debug(f'setup_class add')
                    self.setup_class = method_temp
                elif method_name == 'setup':
                    log.debug(f'setup add')
                    self.setup = method_temp
                elif method_name == 'teardown':
                    log.debug(f'teardown add')
                    self.teardown = method_temp
                elif method_name == 'teardown_class':
                    log.debug(f'teardown_class add')
                    self.teardown_class = method_temp
                else:
                    log.debug(f"method add {method_name}")
                    self.methods[method_name] = method_temp
                    class_methods[method_name] = method_temp

            class_name = path.split(os.sep)[-1].split('.')[0]
            self.method_gen(class_methods, class_name)

            # case裂变
            self.testcase_gen()

        return self

    def method_gen(self, methods, class_name):
        PO = PageObject.class_gen(class_name, methods.keys(), self.get_context())
        self.class_pool[class_name] = PO

    def testcase_gen(self):
        # todo: 生成测试数据
        for name, steps in self.testcases_param.items():
            self.params_data = []
            step_first = steps[0]
            steps_first = []
            found = False
            for index, step in enumerate(steps):
                if 'params' in step.keys():
                    found = True
                    break

            # 更新参数化数据
            if found:
                steps_params = steps[0:index + 1]
                self.params_dict = self.get_context().run_steps(steps_params)
                log.debug(self.params_dict)
                self.data_gen()

                # 利用参数化用例裂变
                for param_data_item in self.params_data:
                    steps_new: list = copy(steps[index:])
                    # 替换params为param
                    steps_new[0] = Step({
                        "param": param_data_item
                    })
                    log.debug("add param testcase")
                    self.testcases[f"{name} {param_data_item}"] = steps_new

            else:
                self.testcases[name] = steps

        log.debug(len(self.testcases))

    def data_gen(self, model=0):
        # todo: 路径遍历
        # todo：all pair
        # https://docs.python.org/zh-cn/3/library/itertools.html

        # params:
        #   a: [1, 2]
        #   b: [3, 4]
        if isinstance(self.params_dict, dict):
            # 简单的配对，是正交的特例
            if model == 0:
                # 取出最大的长度
                size_max = max([len(v) for v in self.params_dict.values() if isinstance(v, list)])
                for index in range(size_max):
                    dict_temp = {}
                    for k in self.params_dict.keys():
                        size_real = len(self.params_dict[k])
                        # 如果长度不够匹配其他的数据，那么自动从头开始取，实现了正交数据生成
                        index_k = index % size_real
                        dict_temp[k] = self.params_dict[k][index_k]
                    self.params_data.append(dict_temp)

        # todo：笛卡尔积
        # params:
        #   - a: 1
        #   - a: 2
        elif isinstance(self.params_dict, list):
            '''
            支持普通的列表表达式
            params:
              - { a: 1, b: 2 }
              - { a: 3, b: 4 }
            '''
            self.params_data = self.params_dict
