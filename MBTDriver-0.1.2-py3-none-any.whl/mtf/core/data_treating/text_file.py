# -*- coding: utf-8 -*-
import re

import jsonpath


class TextFile:
    """
    将 txt 结构化成 python 数据格式
    """

    def __init__(self):
        self._raw_datas = ""
        self._regulars = {}

    def _split_data(self, key, data):
        """
        根据 key 切割 data
        :param key:
        :param data:
        :return:
        """
        # 寻找切割符
        split_keys = set(self._re_searchs(key, data, "GROUP"))
        format_datas = [data]
        # 使用切割符进行切割
        for split_key in split_keys:
            split_data_tmp = []
            # 对数据进行多次切割
            for format_data in format_datas:
                split_data = format_data.split(split_key)
                split_data_tmp += self.__list_strip(split_data)
            format_datas = split_data_tmp.copy()
        # 寻找想要匹配的 groupdict 数据
        find_results = self._re_searchs(key, data, "DICT")
        if len(find_results) != len(format_datas):
            format_datas = format_datas[1:]
        return find_results, format_datas

    def __list_strip(self, data: list):
        """
        删除 list 中首空
        :param data:
        :return:
        """
        if len(data) > 1 and data[0] == "":
            data = data[1:]
        return data

    def __handle_log(self, data, regulars: list):
        """
        根据正则解析 txt 文本
        :param data:
        :param pattern:
        :return:
        """
        result = []
        # for regular in regulars:
        #     result += self.__handle_split(regular, data)

        for regular in regulars:
            tmp_result = []
            # 判断是否要进行拆分
            if regular.get("sub"):
                for expr in regular["pattern"]:
                    for find_result, format_data in zip(*self._split_data(expr, data)):
                        cur_dict = {}
                        cur_dict.update(find_result)
                        pre_results = self.__handle_log(format_data, regular["sub"])
                        for pre_result in pre_results:
                            tmp_dict = cur_dict.copy()
                            pre_result_tmp = pre_result.copy()
                            # 如果没找到，就不替换
                            for key, value in pre_result.items():
                                if value is None:
                                    del pre_result_tmp[key]
                            tmp_dict.update(pre_result_tmp)
                            tmp_result.append(tmp_dict)
                        if not pre_results:
                            tmp_result.append(cur_dict)
            else:
                for expr in regular["pattern"]:
                    tmp_result += self._re_searchs(expr, data)
            result += tmp_result

        return result

    def _re_searchs(self, pattern, data, tag="DICT"):
        """
        多次正则 search 匹配
        :param pattern:
        :param data:
        :return:
        """
        result = []
        # 支持多行匹配
        tmp_data = data
        find_match = re.search(pattern, tmp_data)
        while find_match is not None:
            # 将已经匹配到的内容切割掉
            tmp_data = tmp_data[find_match.end():]
            if tag == "DICT":
                find_result = find_match.groupdict()
            elif tag == "GROUP":
                find_result = find_match.group()
            else:
                find_result = find_match.groupdict()
            # 如果没有 (?<>) ，就用 group
            result.append(find_result)
            find_match = re.search(pattern, tmp_data)
        return result

    def parse(self, raw_datas, regular):
        """
        将 log 结构化
        :return:
        """
        self._regulars = regular
        format_data = self.__handle_log(raw_datas, self._regulars)
        self._format_data = self._update_data(format_data)
        return self._format_data

    def get_format_data(self):
        return self._format_data

    def read_by_jsonpath(self, jsonpath_expr):
        return jsonpath.jsonpath(self._format_data, jsonpath_expr)

    def _update_data(self, format_data):
        """
        对结构化后的数据进行二次处理
        :param data:
        :return:
        """
        return format_data
