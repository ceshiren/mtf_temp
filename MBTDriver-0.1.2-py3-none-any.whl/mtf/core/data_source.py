import pandas as pd
import yaml
import json


class DataSource:
    @classmethod
    def load(cls, file_path, *args, **kwargs):
        file_type = file_path.split('.')[-1]
        if file_type == "txt":
            return cls._open_read(file_path)
        if file_type == "xlsx" or file_type == "xls":
            return cls._open_excel(file_path, *args, **kwargs)
        elif file_type == "csv":
            return cls._open_csv(file_path, *args, **kwargs)
        elif file_type == "yaml" or file_type == "yml":
            f = cls.open_file(file_path)
            return yaml.safe_load(f)
        elif file_type == "json":
            f = cls.open_file(file_path)
            return json.load(f)
        else:
            # dsl
            return cls._open_read(file_path)

    @staticmethod
    def _open_read(path):
        with open(path, errors="ignore") as f:
            return f.read()

    @staticmethod
    def open_file(path):
        """
        打开文件流
        :param path:
        :return:
        """
        return open(path)

    @staticmethod
    def _open_csv(path, columns_start=0, columns_end=None):
        """
        打开 csv
        :param path:
        :param columns_start: 列开始位置
        :param columns_end: 列结束位置
        :return:
        """
        train_data = pd.read_csv(path)
        if columns_end is not None:
            slice_list = train_data.columns[columns_start: columns_end]
        else:
            slice_list = train_data.columns[columns_start:]
        train_data = train_data[slice_list]
        return train_data.to_dict(orient="record")

    @staticmethod
    def _open_excel(path, sheet_name=0):
        """
        打开 excel
        :param path:
        :param sheet_name:
        :return:
        """
        df = pd.read_excel(path, sheet_name=sheet_name)
        return df.to_dict(orient="record")
