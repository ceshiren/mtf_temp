from __future__ import annotations

import pandas as pd
import sqlalchemy
import yaml
import json

from typing import TYPE_CHECKING

from sqlalchemy import Column
from sqlalchemy.engine import reflection
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.testing import db

if TYPE_CHECKING:
    from mtf.core.utils import Utils


class DataSource:
    @classmethod
    def load(cls, file_path, *args, **kwargs):
        file_type = file_path.split('.')[-1]
        if file_type == 'db' or '://' in file_path:
            # 判断字符串为数据库连接
            return cls._open_sql(file_path, *args, **kwargs)
        if len(file_type) < 10:
            from mtf.core.utils import Utils
            file_path = Utils.load(file_path)
        else:
            pass
        if file_type == "txt":
            return cls._open_read(file_path)
        if file_type == "xlsx" or file_type == "xls":
            return cls._open_excel(file_path, *args, **kwargs)
        elif file_type == "csv":
            return cls._open_csv(file_path, *args, **kwargs)
        elif file_type == "yaml" or file_type == "yml":
            f = cls.open_file(file_path)
            return yaml.safe_load(f)
        elif file_type == "json":
            f = cls.open_file(file_path)
            return json.load(f)
        elif file_type == 'xml':
            # todo: seveniruby lixu
            pass
        elif file_type == 'pdf':
            # todo:
            pass
        elif file_type == 'doc' or file_type == 'docx':
            # todo: guoquan
            pass
        elif file_type in ['zip', 'jar', 'war']:
            # todo: xmind也是zip包
            pass
        else:
            # dsl
            return cls._open_read(file_path)

    @staticmethod
    def _open_read(path):
        with open(path, errors="ignore") as f:
            return f.read()

    @staticmethod
    def open_file(path):
        """
        打开文件流
        :param path:
        :return:
        """
        return open(path, encoding='UTF-8')

    @staticmethod
    def _open_csv(path, columns_start=0, columns_end=None):
        """
        打开 csv
        :param path:
        :param columns_start: 列开始位置
        :param columns_end: 列结束位置
        :return:
        """
        train_data = pd.read_csv(path)
        if columns_end is not None:
            slice_list = train_data.columns[columns_start: columns_end]
        else:
            slice_list = train_data.columns[columns_start:]
        train_data = train_data[slice_list]
        return train_data.to_dict()

    @staticmethod
    def _open_excel(path, sheet_name="", columns=None):
        """
        打开 excel
        :param path:
        :param sheet_name:
        :param columns: 取出指定列
        :return:
        """
        df = pd.read_excel(path, sheet_name=sheet_name)
        if columns is not None:
            df = df[columns]
        return df.to_dict()

    @staticmethod
    def _open_sql(sql_url, table_name, *args, **kwargs):
        """
        通过数据库连接和数据库表名，获取表内全部数据
        :param sql_url: 数据库连接URL，示例： 数据库类型+数据库驱动名称://用户名:口令@机器地址:端口号/数据库名
        :param table_name: 数据库表名
        :param args:
        :param kwargs:
        :return:
        """

        def _get_model_class(engine, table_name):
            """
            动态生成表对应的model类
            :param engine:
            :return:
            """
            Base = declarative_base()
            insp = reflection.Inspector.from_engine(engine)
            p_keys = insp.get_pk_constraint(table_name)
            cols = {'__tablename__': table_name, }
            for i in insp.get_columns(table_name):
                if i['name'] in p_keys['constrained_columns']:
                    cols.update({i['name']: Column(i['type'], primary_key=True)})
                else:
                    cols.update({i['name']: Column(i['type'])})

            def to_dict(self):
                """
                将数据转换为字典
                :param self:
                :return:
                """
                return {c.name: getattr(self, c.name, None) for c in self.__table__.columns}

            cols.update({'to_dict': to_dict})
            return type(table_name, (Base,), cols)

        engine = sqlalchemy.create_engine(sql_url, *args, **kwargs)
        db_session = sessionmaker(bind=engine)
        result = db_session().query(_get_model_class(engine, table_name)).all()
        return result

