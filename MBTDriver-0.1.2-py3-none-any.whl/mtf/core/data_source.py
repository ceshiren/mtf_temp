import pandas

class DataSource:
    def load_excel(self):
        pass