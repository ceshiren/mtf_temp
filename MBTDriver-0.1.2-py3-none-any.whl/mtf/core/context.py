from typing import List
from mtf.core.driver.appium_step import AppiumStep
from mtf.core.driver.selenium_step import SeleniumStep
from mtf.core.logger import log
from mtf.core.model import Node
from mtf.core.step import Step
from mtf.core.testcase import TestCase
from mtf.core.testcasestore import TestCaseStore
from mtf.core.utils import Utils


class Context:
    def __init__(self):
        self.store: TestCaseStore = None
        self.testcase: TestCase = None
        self.step: Step = None
        self._return_value = None
        self.context_current = None
        self.tree: Node = Node(None)
        self.cur_node: Node = self.tree
        self.branch = None
        self.steps_include = None
        self.steps_exclude = None

        # 全局数据维护
        self.global_dict = {}
        # 保存每次的参数
        self._param_data_cur = {}

    def load(self, file_name):
        if self.store is None:
            self.store = TestCaseStore()
            self.store.set_context(self)
        else:
            pass

        self.store.load(Utils.load(file_name))
        return self

    def set_context(self, name):
        self.context_current = name

    def set_branch(self, b):
        self.branch = b

    def reset_branch(self):
        self.branch = None

    def add_false(self, step):
        node_step = Node(str(step))
        node_status = Node(False)
        self.add_node(node_step)
        self.add_node(node_status)

    def add_true(self, step):
        node_step = Node(str(step))
        node_status = Node(True)
        self.add_node(node_step)
        self.add_node(node_status)

    def add_node(self, node):
        '''
        如果存在当前节点，就指向当前节点，如果不存在，就创建新的子节点
        :param node:
        :return:
        '''
        found = False
        for child in self.cur_node.children:
            if node.data == child.data:
                found = True
                self.cur_node = child
                break
        if not found:
            self.cur_node.children.append(node)
            self.cur_node = node

    def append_testcase(self, name):
        '''
        从头开始追加用例，确保用例树可以从根开始
        :param name:
        :return:
        '''
        self.cur_node = self.tree
        self.add_node(Node(str(name).split(' ')[0]))

    def append_param_node(self):
        self.add_node(Node(self._param_data_cur))

    def run_steps_by_testcase(self, steps: List[Step]):
        self.testcase = TestCase(steps, self)
        self.testcase.run_steps()

    def run_steps(self, steps: List[Step]):
        for step in steps:
            self.run_step(step)

        return self.return_value()

    def run_step(self, step: Step):
        if self.steps_exclude is not None \
                and len([key for key in step.keys() if key in self.steps_exclude]) > 0:
            log.debug(f"skip {step} when in exclude")
            return self.return_value()
        elif self.steps_include is not None \
                and len([key for key in step.keys() if key in self.steps_include]) == 0:
            log.debug(f"skip {step} when not in include")
            return self.return_value()
        else:
            if 'selenium' in step.keys():
                self.set_context('selenium')
            elif 'appium' in step.keys():
                self.set_context("appium")
            else:
                pass

            if self.context_current == 'selenium':
                step_new = SeleniumStep(step.get_dict())
            elif self.context_current == 'appium':
                step_new = AppiumStep(step.get_dict())
            else:
                step_new = step

            step_new.set_context(self)
            self._return_value = step_new.run()
            return self.return_value()

    def return_value(self):
        return self._return_value

    def set_param(self, kwargs):
        self._param_data_cur = kwargs
