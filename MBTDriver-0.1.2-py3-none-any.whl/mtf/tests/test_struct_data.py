import re
import ast

from mtf.core.utils import Utils


def test_read():
    string1 = "June 15, 1987"
    regex = r"^(?P<month>\w+)\s(?P<day>\d+)\,?\s(?P<year>\d+)"
    matches = re.search(regex, string1)
    print(matches.groupdict())
    assert matches.groupdict()['year'] == '1987'


class CodeAnalyzer(ast.NodeVisitor):
    def visit(self, node):
        print(Utils.to_json_str(node))


def test_dis():
    a = ast.parse('a["xx"] == c')
    print(a)
    j = Utils.to_json_object(a)
    left = j['body'][0]['value']['left']['value']['id']
    right = j['body'][0]['value']['comparators'][0]['id']
    c = compile(a, '<stdin>', mode='exec')
    names = [n for n in dir(c) if str(n).startswith('co_')]
    for n in names:
        print(n)
        print(getattr(c, n))
