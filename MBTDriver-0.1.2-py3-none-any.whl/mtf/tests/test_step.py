from inspect import signature

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.step import Step
from mtf.core.testcasestore import TestCaseStore
from mtf.core.utils import Utils

context = Context()
step = Step(None)
step.set_context(context)


def test_exec():
    step.exec("age=1; name='seveniruby'")
    log.debug(context.global_dict)
    assert context.global_dict['age'] == 1
    assert context.global_dict['name'] == 'seveniruby'
    step.exec("age+=1; name='hogwarts';")
    assert context.global_dict['age'] == 2
    assert context.global_dict['name'] == 'hogwarts'
    step.exec("_return_value=1")
    assert context.global_dict['_return_value'] == 1


def test_exec_return():
    step.exec("age=1")


def test_single():
    from mtf.core.singleton import Singleton
    @Singleton
    class A:
        pass

    x = A()
    y = A()
    assert x is y


def test_function_type():
    assert "o" in signature(Utils.to_json_object).parameters.keys()


def test_recure():
    data = {'a': [{'b': {'c': 2}}], 'd': {'e': {'f': 'fff${f}'}}}

    def recursion(d):
        if isinstance(d, list):
            return [recursion(l) for l in d]
        elif isinstance(d, dict):
            return {k: recursion(v) for k, v in d.items()}
        elif isinstance(d, str):
            return Utils.template(d, {'f': 1})
        else:
            return d

    print(data)
    d2 = recursion(data)
    assert data != d2


def test_update_params():
    step = Step()

    res = step.update_params(
        data={'a': [{'b': {'c1': 2, 'c2': '${f}'}}], 'd': {'e': {'f': 'fff${f}'}}},
        param_dict={'f': 1}
    )
    data2 = {'a': [{'b': {'c1': 2, 'c2': '1'}}], 'd': {'e': {'f': 'fff1'}}}
    assert res == data2

    res = step.update_params(
        data={'a': [{'b': {'c1': 2, 'c2': '$(f+3)'}}], 'd': {'e': {'f': 'fff${f}'}}},
        param_dict={'f': 1}
    )
    data2 = {'a': [{'b': {'c1': 2, 'c2': 4}}], 'd': {'e': {'f': 'fff1'}}}
    assert res == data2


def test_eval():
    data = {
        'a': 1,
        'b': 2
    }
    res = eval("data['a']+1")
    print(type(res))
    print(data)
    print(res)

    data = {
        'a': 1,
        'b': 2
    }
    res = exec("data['b']+=2")

    print(data)
    print(res)

    g = globals()
    l = locals()

    data = {
        'a': 1,
        'b': 2
    }
    exec("data['a']+=1", l)
    print(data)
    print(l['data'])

    print("self")

    class A:
        def a(self):
            f = 1
            print(dict(locals()).keys())
            return eval("self.b", {}, locals())

        def b(self):
            return 7

    print(A().a())

    # assert  2==1
    # c=compile("1==2", '<string>', 'eval')
    # assert eval(c)


def test_safe_eval():
    import ast
    a = 1
    r = ast.literal_eval("[1,2]")
    assert r == [1, 2]


def test_class_define():
    a = type('AA', (object,), dict(sum=lambda self, x: x + 1))
    assert a().sum(1) == 2
    globals()['AAA'] = a
    assert AAA().sum(2) == 3
