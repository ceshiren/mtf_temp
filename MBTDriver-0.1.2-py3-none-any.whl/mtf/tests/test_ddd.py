import pytest

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase


class TestCaseDemoFail(TestBase):
    context = Context()

    def test_param_fail(self, testcase):
        self.context.run_steps_by_testcase(testcase)
