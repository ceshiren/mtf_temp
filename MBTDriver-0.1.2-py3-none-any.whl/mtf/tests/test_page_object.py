from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.page_object import PageObject
from mtf.core.utils import Utils

context = Context()
context.load('test_po.yaml')


def test_method_gen():
    PageObject.method_gen("sum_demo")
    po = PageObject()
    po.set_context(context)
    context.global_dict['a'] = 1
    context.global_dict['b'] = 4
    assert hasattr(po, 'sum_demo')
    po.sum_demo()
    assert po.get_context().return_value() == 5


def test_class_gen():
    PO1 = PageObject.class_gen("c1", ['demo1', 'demo2'])
    PO2 = PageObject.class_gen("c2", ['demo3', 'demo4'])

    po1: PageObject = PO1()
    po1.set_context(context)
    po2: PageObject = PO2()

    log.debug(dir(po1))
    log.debug(dir(po2))
