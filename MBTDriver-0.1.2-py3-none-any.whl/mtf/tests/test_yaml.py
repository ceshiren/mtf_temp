import yaml

from mtf.core.logger import log
from mtf.core.utils import Utils


def test_yaml():
    with open(Utils.get_current_dir(__file__) + "/test_yaml.yaml") as f:
        d = yaml.load(f.read())
        log.debug(d)
