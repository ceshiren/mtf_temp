import pandas

from mtf.core.utils import Utils


def test_load_excel():
    excel=pandas.read_excel(Utils.load('demo.xlsx'), 'Sheet1')
    print(excel)

