from csrmock.core.tcp_server_echo import Forward


def test_forward_start():
    f=Forward()
    # f.start()
