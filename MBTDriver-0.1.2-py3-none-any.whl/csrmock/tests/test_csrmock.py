import os
from subprocess import call


def test_start():
    print(os.getcwd())
    call(["python", '../core/mitm_json.py'])
    print("start ok")