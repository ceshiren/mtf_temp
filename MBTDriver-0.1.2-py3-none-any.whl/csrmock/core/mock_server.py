from typing import List

from mtf.core.logger import log
from mtf.core.utils import Singleton
from csrmock.core.protocol_tcp import ProtocolTcp
from csrmock.core.protocol_json import ProtocolJson
from csrmock.core.protocol_message import ProtocolMessage


@Singleton
class MockServer:

    def __init__(self):
        self.history = []
        self.mock_rules: List[ProtocolMessage] = []

    def set_protocol(self, protocol):
        self.protocol = protocol

    def mock_request(self):
        pass

    def mock_response(self):
        pass

    def add_mock(self, req_matcher, res, protocol=None):
        if protocol is not None:
            self.protocol = protocol
        # todo: add tcp support
        if self.protocol == 'json':
            log.debug(f"add http mock {req_matcher} {res}")
            self.mock_rules.append(ProtocolJson(req_matcher=req_matcher, res=res))
        elif self.protocol == 'mmi':
            self.mock_rules.append(ProtocolTcp(req_matcher=req_matcher, res=res))
        elif self.protocol == 'at':
            pass
        else:
            pass

    def mock(self, req, res):
        for rule in self.mock_rules:
            if rule.filter(req):
                log.debug(f"mock {rule}")
                return rule.encode_res()
        return res

    def reset(self):
        self.history = []
        self.mock_rules = []
