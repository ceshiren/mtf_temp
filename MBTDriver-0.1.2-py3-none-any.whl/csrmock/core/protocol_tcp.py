from struct import unpack, pack

from mtf.core.logger import log
from csrmock.core.protocol.protocol_message import ProtocolMessage


class ProtocolTcp(ProtocolMessage):

    def encode_res(self):
        log.debug(self.res)
        format_str = ['<']
        format_value = []
        for r in self.res:
            if isinstance(r, int):
                format_str.append('h')
                format_value.append(r)
            elif isinstance(r, str):
                format_str.append(f'{len(r.encode())}s')
                format_value.append(r.encode())
        log.debug(format_str)
        byte_array = pack(''.join(format_str), *format_value)
        log.debug(byte_array)
        return byte_array

    def decode_req(self, req_real):
        data = {}
        index = 1
        for t in unpack("<4h", req_real[0:8]):
            data[f"f{index}"] = t
            index += 1
        return data
