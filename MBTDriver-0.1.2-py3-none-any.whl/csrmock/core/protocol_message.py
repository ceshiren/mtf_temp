import json

from jsonpath import jsonpath

from mtf.core.logger import log
from mtf.core.utils import Utils


class ProtocolMessage:
    def __init__(self, req_matcher, res):
        self.req_matcher = req_matcher
        self.res = res
        self.req = None

    def encode_res(self):
        return self.res

    def decode_req(self, req):
        return self.req

    def filter(self, req_real):
        req = self.decode_req(req_real)
        log.debug(Utils.to_json_str([req]))
        log.debug(self.req_matcher)
        result = jsonpath(json.loads(Utils.to_json_str([req])), self.req_matcher)
        log.debug(result)
        return result
