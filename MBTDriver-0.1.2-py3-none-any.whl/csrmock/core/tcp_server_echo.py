import socket
import threading
from time import sleep

from mtf.core.logger import log
from mtf.core.singleton import Singleton
from mtf.core.utils import Utils
import asyncio


@Singleton
class EchoServer:
    host = '127.0.0.1'  # Standard loopback interface address (localhost)
    port = 65432  # Port to listen on (non-privileged ports are > 1023)
    conn = None

    def start(self):
        if self.conn is None:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                self.conn = s
                log.info(f"bind {s} ")
                s.bind((self.host, self.port))
                s.listen()
                conn, addr = s.accept()
                with conn:
                    while True:
                        data = conn.recv(1024)
                        if not data:
                            break
                        conn.sendall(data)
        else:
            pass
        return self.conn

    async def handle_echo(reader, writer):
        data = await reader.read(100)
        message = data.decode()
        addr = writer.get_extra_info('peername')

        print(f"Received {message!r} from {addr!r}")

        print(f"Send: {message!r}")
        writer.write(data)
        await writer.drain()

        print("Close the connection")
        writer.close()

    async def main(self):
        server = await asyncio.start_server(
            self.handle_echo, '127.0.0.1', 8888)

        addr = server.sockets[0].getsockname()
        print(f'Serving on {addr}')

        async with server:
            await server.serve_forever()

    def start_in_background(self):
        thread = threading.Thread(
            target=self.start
        )
        thread.start()

    def start_in_async(self):
        asyncio.run(self.main())


class EchoClient:

    def __init__(self):
        self.conn = None

    def connect(self, host, port):
        self.conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        return self.conn


class Forward:
    async def tcp_echo_client(self, message):
        reader1, writer1 = await asyncio.open_connection(
            '127.0.0.1', 7777)
        reader2, writer2 = await asyncio.open_connection(
            '127.0.0.1', 7778)

        data = await reader1.read(2)
        print(f'Received: {data.decode()!r}')
        writer1.write(data)
        #
        # print('Close the connection')
        # writer.close()

    def start(self):
        asyncio.run(self.tcp_echo_client('Hello World!'), debug=True)
