import json
import re

from flask import Flask, request, jsonify, current_app

from mtf.core.logger import log
from mtf.core.utils import Singleton, Utils
from csrmock.core.mock_server import MockServer


class CallBackServer:
    app = Flask(__name__)

    def __init__(self):
        pass

    def set_mock_server(self, mock_server):
        self.mock_server: MockServer = mock_server
        # self.app.config['mock_server']=self.mock_server


    @staticmethod
    @app.route('/', methods=['get'])
    def info():
        return {
            'data': Utils.to_json_object(MockServer()),
            'instance': str(MockServer()),
            'msg': 'ok'
        }

    # @staticmethod
    # @app.route('/<path:path>', methods=['get', 'post'])
    # def callback(path):
    #     print(request.data)
    #     req = {
    #         'args': request.args,
    #         'data': request.get_data(as_text=True),
    #         'path': request.path,
    #         'json': request.json
    #     }
    #     # current_app.config['history'].append(req)
    #     # print(json.dumps(req))
    #
    #     for mock in CallBackServer().get_mock_list():
    #         # print(jsonpath.jsonpath(req, core['req']))
    #         if len(re.findall(mock['req'], json.dumps(req))) > 0:
    #             return mock["res"]
    #         else:
    #             pass
    #
    #     return jsonify(req)



    @staticmethod
    @app.route('/core', methods=['get', 'post'])
    def mock():
        log.info(request.headers)

        method = str(request.method).lower()
        if method == 'post':

            log.info(f'{request.json}')
            req = request.json['req']
            res = request.json['res']
            MockServer().add_mock(req_matcher=req, res=res)
        else:
            pass
        return {
            'data': Utils.to_json_object(MockServer().mock_rules),
            'size': len(MockServer().mock_rules),
            'msg': 'ok'
        }

    @staticmethod
    @app.route('/history', methods=['get'])
    def history():
        return {
            'data': Utils.to_json_object(MockServer().history),
            'size': len(MockServer().history),
            'msg': 'ok'
        }

    @staticmethod
    @app.route('/reset', methods=['post'])
    def reset():
        MockServer().reset()
        return {
            'data': Utils.to_json_object(MockServer().history),
            'size': len(MockServer().history),
            'msg': 'ok'
        }

    def start_server(self, port=8008):
        self.app.run(debug=True, port=port, use_reloader=False)


if __name__ == '__main__':
    CallBackServer().start_server()
