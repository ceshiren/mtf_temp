"""HTTP-specific events."""
import sys
import threading

import mitmproxy.http
from mitmproxy import ctx
from mitmproxy.tools.main import mitmdump

from csrmock.core.mock_server import MockServer


class MitmJson:

    def __init__(self):
        self.mock_server = MockServer()
        self.mock_server.set_protocol('json')
        print(self.mock_server)

    def handle_mock(self, flow: mitmproxy.http.HTTPFlow):
        flow.response = self.mock_server.mock(flow.request, flow.response)
        self.mock_server.history.append({
            'req': flow.request,
            'res': flow.response
        })

    def http_connect(self, flow: mitmproxy.http.HTTPFlow):
        """
            An HTTP CONNECT request was received. Setting a non 2xx response on
            the flow will return the response to the client abort the
            connection. CONNECT requests and responses do not generate the usual
            HTTP handler events. CONNECT requests are only valid in regular and
            upstream proxy modes.
        """

    def requestheaders(self, flow: mitmproxy.http.HTTPFlow):
        """
            HTTP request headers were successfully read. At this point, the body
            is empty.
        """

    def request(self, flow: mitmproxy.http.HTTPFlow):
        """
            The full HTTP request has been read.
        """
        self.handle_mock(flow)

    def responseheaders(self, flow: mitmproxy.http.HTTPFlow):
        """
            HTTP response headers were successfully read. At this point, the body
            is empty.
        """

    def response(self, flow: mitmproxy.http.HTTPFlow):
        """
            The full HTTP response has been read.
        """
        # self.handle_mock(flow)

    def error(self, flow: mitmproxy.http.HTTPFlow):
        """
            An HTTP error has occurred, e.g. invalid server responses, or
            interrupted connections. This is distinct from a valid server HTTP
            error response, which is simply a response with an HTTP error code.
        """
        # self.handle_mock(flow)

    @classmethod
    def main(cls):
        sys.argv += [
            "-p", "8001",
            "-m", "reverse:http://127.0.0.1:8567/",
            "-s", __file__
        ]

        from csrmock.core.callback_server import CallBackServer

        callback = CallBackServer()
        thread_callback = threading.Thread(
            target=callback.start_server,
            name="callback",
            kwargs={'port': 8002}
        )
        thread_callback.start()
        # 官方要求必须主线程
        mitmdump()


addons = [
    MitmJson()
]
if __name__ == '__main__':
    MitmJson.main()
