from csrmock.core.tcp_server_echo import EchoServer

if __name__ == '__main__':
    echo = EchoServer()
    echo.start_in_background()
    print('main')
