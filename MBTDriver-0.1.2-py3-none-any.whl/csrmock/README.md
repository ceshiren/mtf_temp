# csrmock

## quick start



```
#用例启动之前 setup set_class
curl http://127.0.0.1:8001/mock \
  -d '{ "req": "1", "res": "mock demo 1"}' \
  -H "content-type: application/json"

#手机apk发送的请求
curl http://127.0.0.1:8001/2233?xxx=1 -d '{ "a": 1}' -H "content-type: application/json"

#断言阶段
curl http://127.0.0.1:8001/history

```

## json mock
8001是mock server，8002 mock server的管理端口
```bash
curl http://127.0.0.1:8002/mock \
  -d '{ "req": "$..[?(@.method==\"GET\")]", "res": "80 port mock demo" }' \
  -H "content-type: application/json"
curl http://127.0.0.1:8001/demo
curl http://127.0.0.1:8002/history
```

## tcp mock
8003是tcp mock server，8004是管理端口
```bash
# 开启tcp server
# nc -l 7777 -k < /tmp/1.txt
curl http://127.0.0.1:8004/mock \
  -d '{"req": "$..[?(@.f1==12849)]", "res": "mock demo" } ' \
  -H "content-type: application/json"
echo 12345678 |  nc 127.0.0.1  8003 -v
curl http://127.0.0.1:8004/history
```

## 架构

![流程图](https://plantuml.ceshiren.com/svg/oyrFpevFpibCpIjHKD2rKqXEpCb9IWIA5QSMbQKMALWfP9IK572X2mDLvkOZgqeioEH25W4gA2ZABybFpi-1o080)